package com.utility;

import java.util.ArrayList;
import java.util.List;

import com.bean.Student;

public class College {

	private List<Student> studentlist = new ArrayList<Student>();

	public List<Student> getStudentlist() {
		return studentlist;
	}

	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}

	// Add the student object into the studentList
	public void addStudent(Student studentObj) {
		this.studentlist.add(studentObj);

	}

	// method should returns the total number students based on the grade
	public int countBasedOnGrade(String Grade) {
		int countNoOfStudents;
		countNoOfStudents=0;
		for (Student std : studentlist) {
			if (std.getGrade().equals(Grade))
				countNoOfStudents++;
		}
		return countNoOfStudents;

	}
}
