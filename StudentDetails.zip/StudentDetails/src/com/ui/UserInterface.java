package com.ui;

import java.util.Scanner;

import com.bean.Student;
import com.utility.College;

public class UserInterface {

	public static void main(String a[]) {

		System.out.println("Enter the number of student details");
		Scanner yourvar = new Scanner(System.in);
		College you = new College();
		int yourvar1 = 0;
		int i = 0;
		yourvar1 = Integer.parseInt(yourvar.nextLine());
		System.out.println("Enter the student details");
		

		while (i < yourvar1) {
			String inputString = yourvar.nextLine();
			Student studentObj = new Student();
			studentObj.parseData(inputString);
			you.addStudent(studentObj);
			i++;
		}

		System.out.println("Enter the grade");
		System.out.println("Count:" + you.countBasedOnGrade(yourvar.nextLine()));
		yourvar.close();
	}

}
