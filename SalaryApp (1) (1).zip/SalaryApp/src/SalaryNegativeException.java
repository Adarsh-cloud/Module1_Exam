//make the necessary change to make this class a Exception
public class SalaryNegativeException extends Exception
{
	private static final long serialVersionUID = 1L;

	public SalaryNegativeException() 
	{
		System.out.println("Invalid Salary");
	}
}
