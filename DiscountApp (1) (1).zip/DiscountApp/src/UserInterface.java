
import java.util.Scanner;
public class UserInterface 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int noOfProducts=sc.nextInt();
		String products[]=new String[noOfProducts];
		
		for(int i=0;i<noOfProducts;i++)
		{
			products[i]=sc.next();
		}
		
		
		float dis1 = 100000.0f;
		String prod1 = null;
		
		float dis2 = 100000.0f;
		String prod2 = null;
		for(int i=0;i<noOfProducts;i++)
		{
			String[] sepProd = products[i].split(",");
			
			float disc = (Integer.parseInt(sepProd[1])*Integer.parseInt(sepProd[2]))/100;
			System.out.println(disc);
			if(disc<dis1)
			{
				dis1 = disc;
				prod1 = sepProd[0];
			}
			
			else if(disc == dis1)
			{
				dis2 = disc;
				prod2 = sepProd[0];
			}
		}
		
		System.out.println(prod1 + " " +  dis1);
		
		if(dis2 == dis1)
		{
			System.out.println(prod2 + " " +  dis2);
		}
		
		
		
		
		sc.close();
	}

}
