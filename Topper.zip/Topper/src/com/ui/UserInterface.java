package com.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.utility.StudentUtility;

public class UserInterface {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		
		int noOfStudents = 0;
		StudentUtility studUtility = new StudentUtility();
		studUtility.setStudentMap(new HashMap<Integer, Integer>());
		System.out.println("Enter the no of Students:");
		noOfStudents = Integer.parseInt(sc.nextLine());

		for (int index = 1; index <= noOfStudents; index++) {
			int rollNo = 0, marks = 0;
			System.out.println("Enter rollno of Student " + index);
			rollNo = Integer.parseInt(sc.nextLine());
			System.out.println("Enter mark of Student " + index);
			marks = Integer.parseInt(sc.nextLine());
			studUtility.addStudentDetails(rollNo, marks);
		}

		Map<Integer, Integer> stud = studUtility.getStudentMap();
		Set<Integer> keySet = stud.keySet();
		for (Integer key : keySet) {
			System.out.println(key+" "+stud.get(key));
		}

		List<Integer> toppers = studUtility.findToppers();
		System.out.println("Toppers List");
		for (int in = 0; in < toppers.size() - 1; in++)
			System.out.print(toppers.get(in) + ",");
		System.out.print(toppers.get(toppers.size() - 1));
		sc.close();

	}

	}



