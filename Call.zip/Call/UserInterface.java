package Call;

import java.util.Scanner;

public class UserInterface {
	
	public static void main(String a[]){
		Scanner sc=new Scanner(System.in);
		int n = 0;
		Scanner scanner = new Scanner(System.in);
		CallHistory callH = new CallHistory();
		System.out.println("Enter the number of student details");
		n = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter the student details");
		for (int i = 0; i < n; i++) {
			String details = scanner.nextLine();
			Call call1 = new Call();
			call1.parseData(details);
			callH.addCall(call1);
		}
		System.out.println("Enter the grade");
		long time = scanner.nextLong();
		System.out.println("Count:" + callH.findTotalDuration(time));
		scanner.close();
	}

}
