package Call;

import java.util.ArrayList;
import java.util.List;



public class CallHistory {
	private List<Call> callList=new ArrayList<Call>();

	public List<Call> getCallList() {
		return callList;
	}

	public void setCallList(List<Call> callList) {
		this.callList = callList;
	}
	
	// This method should add the callObject into callList
	public void addCall(Call callObject){
		callList.add(callObject);
	}
	
	//this method returns the total duration (float) spent to a particular callednumber
	public float findTotalDuration(long calledNumber){
		
		return calledNumber;
	}

}

