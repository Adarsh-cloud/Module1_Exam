package Call;

public class Call {
	private int callId;
	private long calledNumber;
	private float duration;
	private int id;
	public int getCallId() {
		return callId;
	}
	
	public long getCalledNumber() {
		return calledNumber;
	}
	
	public float getDuration() {
		return duration;
	}

	public void setCallId(int callId) {
		this.callId = callId;
	}

	public void setCalledNumber(long calledNumber) {
		this.calledNumber = calledNumber;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}

	public void parseData(String details)
	{
		Call ca = new Call();
		String[] str = details.split(":");
		for(int i=0;i<str.length;i++){
			//conditions to set callId, calledNumber,duration
			if(i==0){
				ca.setCallId(Integer.parseInt(str[0]));
			}
			else if(i==1){
				
				setCalledNumber(Long.parseLong(str[1]));
			}
			else if (i==2){
				
				setDuration(Float.parseFloat(str[2]));
			}
		}
	}

}
